classdef robot
    %ROBOT-The robot function connector
    % Includes functions for registration, planning, targeting, moving the
    % robot, as well as feedback current location
    
    properties (Access = private)
        current_mode = 'stop'
        max_insertion_speed = 0.5 
        max_rotation_speed = 4*pi
        max_error_allowed = 0.05
        close_value = 0.1
        % should have an external function for getting current_robot_position
        starting_position
        target_position_robot
        is_target_reached
        previou_needle_pose_MRI
        registration_matrix = [1, 0., 0., 0.; 0., 1, 0., 0.; 0., 0., 1, 0.; 0., 0., 0., 1]
        validModes = ['startup', 'calibration', 'planning', 'targeting',...
                             'idle', 'move_to_goal', 'stop'];
    end

    
    methods
        function obj = robot(inputArg1,inputArg2)
            %ROBOT Construct an instance of this class
            %   Detailed explanation goes here
            obj.Property1 = inputArg1 + inputArg2;
        end
        
        function obj = startup(obj)
            % Set all needed sensors and relay on
            % do_neccessary_bring_up();
            obj.current_mode = 'startup';
        end

        function robot_not_ready = is_startup(obj)
            %   Check if the robot has been startup properly
            robot_not_ready = strcmp(obj.current_mode, 'stop');
        end

        function robot_mode = check_robot_mode(obj)
            %   Return the current mode of the robot
            robot_mode = obj.current_mode;
        end
        
        function obj = set_robot_mode(obj, mode)
            % adjust robot mode, right now is more alike a connection check
            if ismember(mode, obj.validModes)
                obj.current_mode = mode;
            end
        end

        function robot_pose = get_robot_current_pose()
            % Return the current robot pose in robot cordinate, should call
            % your external function to get this
            robot_pose = current_robot_position();
        end
        
        function calibration_finsh_flag = calibrate(obj, recieved_matrix)
            % Calibrate the robot with respect to image frame, it seems
            % from Farid's code, the matrix from slicer is the registration
            % matrix already.
            origin = obj.registration_matrix;
            obj.registration_matrix = recieved_matrix;
            tolerance = 1e-6;
            calibration_finsh_flag = ~isequal(size(origin), size(obj.registration_matrix)) && all(abs(origin - obj.registration_matrix) < tolerance, 'all');
        end
        
        function target_in_robot_frame = target_registration(obj, target)
            % Transfer recieved point/transformation to robot frame.
            target_in_robot_frame = obj.registration_matrix \ target;
        end
        
        function is_reachable = reachable(obj, target)
            %waiting for development, check if the target is reachable by
            %furthest insertion
        end
        
        function obj = update_target(obj, target)
            obj.target_position_robot = target;
        end

        function planning_finsh_flag = planning(obj, target)
            target_robot = obj.target_registration(target);
            %checking reachability can be external function as well, but
            %give you the interface anyway
            planning_finsh_flag = obj.reachable(target_robot);
        end
        
        function is_in_workspace = check_target(obj, target)
            target_robot = obj.target_registration(target);
            %checking reachability can be external function as well, but
            %give you the interface anyway
            is_in_workspace = obj.reachable(target_robot);
            if is_in_workspace
                obj.update_target(target_robot);
            end
        end
        
        function move_to_end(obj)
            %   Main action function for open loop. Only one traget is
            %   there, no mid-step needed. Could use a compensation method
            obj.starting_position = current_robot_position();
            move(obj.target_position_robot);
            obj.RetractNeedle(obj.starting_position);
        end
        
        function next_step = calculate_next_step(obj, needle_pos, slow_flag)
            % Setpoint preparation function, you can either feedback one
            % next step, or a path
            if slow_flag
                next_step = xxxx(needle_pos,obj.target_position_robot,small_step_value);
            else
                next_step = xxxx(needle_pos,obj.target_position_robot,large_step_value);
            end
        end
        
        function RetractNeedle(obj)
            % The retract function after insertion
            move(obj.starting_position);
        end

        function slow_flag = isApprox(obj,needle_pos)
            % Use robot pose and needle pose to check if we are close. If
            % close, move smaller steps
            current_pos = current_robot_position();
            if obj.target_position_robot - mean(current_pos, needle_pos) < close_value %this value should add to properties and constructive funtion.
                slow_flag = true;
            else
                slow_flag = false;
            end
        end
        
        function obj = update_flag(obj, flag)
            obj.is_target_reached = flag;
        end

        function hit_flag = isInTargetingPos(obj, needle_pos)
            %   Use current robot feedback and image feedback to see if hit
            %   target (error apply).
            current_pos = current_robot_position();
            %   The if condition is just a logic indication, please try to
            %   write an external function for it.
            if obj.target_position_robot - mean(current_pos, needle_pos) < max_error_allowed %this value should add to properties and constructive funtion.
                hit_flag = true;
            else
                hit_flag = false;
            end
            obj.update_flag(hit_flag);
        end
        
        function obj = set_entry_point(obj, needle_image)
            current_pos = current_robot_position();
            needle_pos = obj.target_registration(needle_image);
            obj.starting_position = 0.3 .* current_pos + 0.7 .* needle_pos;
        end

        function move_A_step(obj, needle_pos_image)
        %   Simply move the robot to next step. Sorry need to break your
        %   continuety.
            needle_pos_robot = obj.target_registration(needle_pos_image);
            slow_flag = obj.isApprox(needle_pos_robot);
            hit_flag = isInTargetingPos(needle_pos_robot);
            if hit_flag
                obj.RetractNeedle();
            else
                next_step = calculate_next_step(needle_pos_robot, slow_flag);
                % Your function to move a small step, but should keep
                % tracking kinematics and kalman filter
                move_step(next_step,needle_pos_robot);
            end


        end

        function obj = stop(obj)
            %   Shut down the robot
             % do_neccessary_shut_down();
            obj.current_mode = 'stop';
        end


    end
end

